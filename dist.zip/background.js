//#region src/lib/storage.ts
async function e() {
	if (typeof chrome > "u" || !chrome.storage) {
		let e = localStorage.getItem("shelf_reminders");
		return e ? JSON.parse(e) : [];
	}
	let e = (await chrome.storage.local.get("reminders")).reminders || {};
	return Object.values(e).sort((e, t) => e.remindAt - t.remindAt);
}
async function t(t) {
	return typeof chrome > "u" || !chrome.storage ? (await e()).find((e) => e.id === t) : ((await chrome.storage.local.get("reminders")).reminders || {})[t];
}
async function n(t) {
	if (typeof chrome > "u" || !chrome.storage) {
		let n = await e(), r = n.findIndex((e) => e.id === t.id);
		r > -1 ? n[r] = t : n.push(t), localStorage.setItem("shelf_reminders", JSON.stringify(n));
		return;
	}
	let n = (await chrome.storage.local.get("reminders")).reminders || {};
	n[t.id] = t, await chrome.storage.local.set({ reminders: n }), !t.delivered && t.remindAt > Date.now() ? await chrome.alarms.create(t.id, { when: t.remindAt }) : await chrome.alarms.clear(t.id);
}
async function r(t) {
	if (typeof chrome > "u" || !chrome.storage) {
		let n = (await e()).filter((e) => e.id !== t);
		localStorage.setItem("shelf_reminders", JSON.stringify(n));
		return;
	}
	let n = (await chrome.storage.local.get("reminders")).reminders || {};
	delete n[t], await chrome.storage.local.set({ reminders: n }), await chrome.alarms.clear(t);
}
//#endregion
//#region src/background/index.ts
var i = "shelf-page", a = "shelf-link";
function o() {
	return chrome.runtime.getURL("icon.png");
}
chrome.runtime.onInstalled.addListener(async () => {
	await chrome.contextMenus.removeAll(), await chrome.contextMenus.create({
		id: i,
		title: "Shelf This Page",
		contexts: ["page"]
	}), await chrome.contextMenus.create({
		id: a,
		title: "Shelf This Link",
		contexts: ["link"]
	}), await m();
}), chrome.contextMenus.onClicked.addListener(async (e, t) => {
	let r = "", s = "";
	if (e.menuItemId === i) r = e.pageUrl || "", s = t?.title || "Webpage";
	else if (e.menuItemId === a && (r = e.linkUrl || "", s = e.selectionText || "", !s)) try {
		s = new URL(r).hostname;
	} catch {
		s = "Shared Link";
	}
	if (f(r)) {
		let e = Date.now() + 1800 * 1e3, t = {
			id: crypto.randomUUID(),
			title: s.trim() || "Webpage",
			url: r,
			createdAt: Date.now(),
			remindAt: e,
			delivered: !1
		};
		try {
			await n(t);
		} catch (e) {
			console.error("Failed to save context menu item:", e);
			return;
		}
		try {
			if (await chrome.storage.local.set({ editItemId: t.id }), typeof chrome.action.openPopup != "function") throw Error("Opening the action popup requires Chrome 127 or newer.");
			await chrome.action.openPopup();
		} catch (e) {
			console.error("Saved item, but could not open the Shelf popup:", e), chrome.notifications.create(t.id + "-save", {
				type: "basic",
				iconUrl: o(),
				title: "Saved to Shelf",
				message: "Click the Shelf toolbar icon to adjust its reminder settings.",
				requireInteraction: !1
			});
		}
	}
});
async function s(e) {}
function c(e) {
	let t = new Date(e);
	return `${String(t.getHours()).padStart(2, "0")}:${String(t.getMinutes()).padStart(2, "0")}`;
}
function l(e) {
	let [t, n] = e.split(":").map(Number), r = /* @__PURE__ */ new Date();
	return r.setHours(t, n, 0, 0), r.getTime() <= Date.now() && r.setDate(r.getDate() + 1), r.getTime();
}
var u = !1;
async function d(t = 0) {
	if (!u) {
		u = !0;
		try {
			t > 0 && await new Promise((e) => setTimeout(e, t));
			let r = await e(), i = Date.now(), a = r.filter((e) => e.remindAt <= i && !e.delivered);
			await s(`checkOverdueReminders: found ${a.length} overdue items`);
			for (let e of a) {
				if (e.everyday) {
					let t = l(e.everydayTime || c(e.remindAt));
					await n({
						...e,
						remindAt: t,
						delivered: !1
					});
				} else await n({
					...e,
					delivered: !0
				});
				await s(`Creating overdue notification for: ${e.title} (ID: ${e.id})`), chrome.notifications.create(e.id, {
					type: "basic",
					iconUrl: o(),
					title: "Shelf Reminder (Overdue)",
					message: e.title,
					contextMessage: e.note || void 0,
					buttons: [{ title: "Open Page" }, { title: "Postpone 15m" }],
					requireInteraction: !0
				});
			}
		} catch (e) {
			await s(`Error checking overdue reminders: ${e}`), console.error("Error checking overdue reminders:", e);
		} finally {
			u = !1;
		}
	}
}
chrome.alarms.onAlarm.addListener(async (e) => {
	try {
		await s(`onAlarm triggered: name=${e.name}`);
		let r = await t(e.name);
		if (!r) {
			await s(`onAlarm: item not found for alarm ${e.name}`);
			return;
		}
		if (r.delivered) {
			await s(`onAlarm: item "${r.title}" already delivered`);
			return;
		}
		if (await s(`onAlarm: creating notification for "${r.title}"`), chrome.notifications.create(r.id, {
			type: "basic",
			iconUrl: o(),
			title: "Shelf Reminder",
			message: r.title,
			contextMessage: r.note || void 0,
			buttons: [{ title: "Open Page" }, { title: "Postpone 15m" }],
			requireInteraction: !0
		}), r.everyday) {
			let e = l(r.everydayTime || c(r.remindAt));
			await n({
				...r,
				remindAt: e,
				delivered: !1
			});
		} else await n({
			...r,
			delivered: !0
		});
	} catch (e) {
		await s(`Error in onAlarm listener: ${e}`), console.error("Error in onAlarm listener:", e);
	}
});
function f(e) {
	try {
		let t = new URL(e).protocol;
		return t === "http:" || t === "https:";
	} catch {
		return !1;
	}
}
async function p(e) {
	if (!f(e)) return !1;
	try {
		return await chrome.tabs.create({ url: e }), !0;
	} catch (e) {
		return await s(`chrome.tabs.create failed: ${e}`), console.error("Failed to open URL:", e), !1;
	}
}
chrome.notifications.onButtonClicked.addListener(async (e, i) => {
	try {
		if (await s(`onButtonClicked: id=${e}, buttonIndex=${i}`), e.endsWith("-save")) {
			let n = e.replace("-save", "");
			if (!await t(n)) {
				await s(`onButtonClicked save-confirm: item not found for originalId=${n}`), chrome.notifications.clear(e);
				return;
			}
			i === 0 ? (await s("onButtonClicked save-confirm: clicked Okay"), chrome.notifications.clear(e)) : i === 1 && (await s("onButtonClicked save-confirm: clicked Edit Time"), await p(chrome.runtime.getURL(`options.html?action=edit&id=${n}`)), chrome.notifications.clear(e));
			return;
		}
		let a = await t(e);
		if (!a) {
			await s(`onButtonClicked normal: item not found for id=${e}`), chrome.notifications.clear(e);
			return;
		}
		if (i === 0) {
			await s(`onButtonClicked normal: Open Page clicked for "${a.title}"`);
			let t = await p(a.url);
			await s(`onButtonClicked normal: openUrl success: ${t}`), t && (a.everyday || await r(e)), chrome.notifications.clear(e);
		} else if (i === 1) {
			await s(`onButtonClicked normal: Postpone clicked for "${a.title}"`);
			let t = Date.now() + 900 * 1e3;
			await n({
				...a,
				remindAt: t,
				delivered: !1
			}), await s(`onButtonClicked normal: Postpone saved newRemindAt=${new Date(t).toLocaleTimeString()}`), chrome.notifications.clear(e), chrome.notifications.create(a.id + "-snoozed", {
				type: "basic",
				iconUrl: o(),
				title: "Snoozed",
				message: "Reminder postponed for 15 minutes.",
				requireInteraction: !1
			});
		}
	} catch (e) {
		await s(`Error in onButtonClicked: ${e}`), console.error("Error in onButtonClicked listener:", e);
	}
}), chrome.notifications.onClicked.addListener(async (e) => {
	try {
		if (await s(`onClicked (body click): id=${e}`), e.endsWith("-save") || e.endsWith("-snoozed")) {
			chrome.notifications.clear(e);
			return;
		}
		let n = await t(e);
		n ? (await s(`onClicked (body click): opening "${n.title}"`), await p(n.url) && (n.everyday || await r(e))) : await s(`onClicked (body click): item not found for id=${e}`), chrome.notifications.clear(e);
	} catch (e) {
		await s(`Error in onClicked listener: ${e}`), console.error("Error in onClicked listener:", e);
	}
});
async function m() {
	let t = await e(), n = Date.now();
	for (let e of t) !e.delivered && e.remindAt > n && await chrome.alarms.create(e.id, { when: e.remindAt });
	await d();
}
chrome.runtime.onStartup.addListener(async () => {
	await m();
}), m(), chrome.runtime.onMessage.addListener((e) => {
	if (e.type === "NOTIFY_SAVED") {
		try {
			let { item: t, timeMsg: n } = e;
			chrome.notifications.create(t.id + "-save", {
				type: "basic",
				iconUrl: o(),
				title: "Saved to Shelf",
				message: `"${t.title}" will remind you ${n}.`,
				buttons: [{ title: "Okay" }, { title: "Edit Time" }],
				requireInteraction: !1
			});
		} catch (e) {
			console.error("Error creating saved notification in response to message:", e);
		}
		return;
	} else if (e.type === "OPEN_AND_REMOVE") {
		let { id: i } = e;
		return (async () => {
			try {
				let e = await t(i);
				if (e && await p(e.url) && e) if (e.everyday) {
					let t = l(e.everydayTime || c(e.remindAt));
					await n({
						...e,
						remindAt: t,
						delivered: !1
					});
				} else await r(i);
			} catch (e) {
				console.error("Error opening and removing item in response to message:", e);
			}
		})(), !0;
	}
});
//#endregion
